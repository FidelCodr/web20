<?php

add_filter( 'wp_nav_menu_items', 'unicase_style_icl_languages_dropdown', PHP_INT_MAX, 2 );