<?php
/*
    Extension Name: Post Formats
    Version: 1.0
    Description: User interface and controls for post formats.
*/

require get_template_directory() . '/inc/admin/post-formats/post-formats.php';